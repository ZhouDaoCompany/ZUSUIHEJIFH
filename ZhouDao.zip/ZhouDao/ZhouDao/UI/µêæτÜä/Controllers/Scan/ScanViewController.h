//
//  ScanViewController.h
//  ZhouDao
//
//  Created by apple on 16/7/8.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ScanViewController : BaseViewController

@end
