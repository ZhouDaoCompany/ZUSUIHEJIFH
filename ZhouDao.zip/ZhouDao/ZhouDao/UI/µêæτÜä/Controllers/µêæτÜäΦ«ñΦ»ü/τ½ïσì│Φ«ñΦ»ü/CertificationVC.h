//
//  CertificationVC.h
//  ZhouDao
//
//  Created by apple on 16/3/11.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface CertificationVC : BaseViewController

@property (nonatomic, copy) ZDObjectBlock imgBlock;

@end
