//
//  OrderTitleLab.h
//  ULife
//
//  Created by tcnj on 15/7/27.
//  Copyright (c) 2015年 UHouse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderTitleLab : UILabel

@property (nonatomic,assign) CGFloat scale;

@end
