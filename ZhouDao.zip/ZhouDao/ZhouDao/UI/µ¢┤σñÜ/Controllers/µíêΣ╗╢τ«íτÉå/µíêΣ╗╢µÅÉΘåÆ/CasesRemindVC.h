//
//  CasesRemindVC.h
//  ZhouDao
//
//  Created by apple on 16/7/1.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface CasesRemindVC : BaseViewController



@property (nonatomic, copy) NSString *caseId;//案件ID

@end
