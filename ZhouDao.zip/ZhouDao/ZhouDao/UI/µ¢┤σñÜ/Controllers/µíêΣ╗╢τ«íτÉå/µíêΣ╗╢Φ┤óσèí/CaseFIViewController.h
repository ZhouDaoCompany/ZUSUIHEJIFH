//
//  CaseFIViewController.h
//  ZhouDao
//
//  Created by apple on 16/6/21.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface CaseFIViewController : BaseViewController

@property (nonatomic, copy) NSString *caseId;//案件ID

@end
