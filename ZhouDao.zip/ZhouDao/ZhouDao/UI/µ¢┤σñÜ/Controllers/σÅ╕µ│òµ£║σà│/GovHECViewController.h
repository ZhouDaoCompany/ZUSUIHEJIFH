//
//  GovHECViewController.h
//  ZhouDao
//
//  Created by apple on 16/8/11.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "GovListmodel.h"

@interface GovHECViewController : BaseViewController

@property (nonatomic, strong) GovListmodel *model;
@end
