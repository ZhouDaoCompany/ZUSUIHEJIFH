//
//  ExampleSearView.h
//  ZhouDao
//
//  Created by apple on 16/4/13.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExampleSearView : UICollectionReusableView

@property (nonatomic, copy) ZDStringBlock searchBlock;
@end
