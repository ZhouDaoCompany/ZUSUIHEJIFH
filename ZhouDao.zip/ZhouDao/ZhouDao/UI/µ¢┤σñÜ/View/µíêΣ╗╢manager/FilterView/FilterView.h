//
//  FilterView.h
//  UItext
//
//  Created by apple on 16/4/12.
//  Copyright © 2016年 cqz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilterView : UIView

@property (nonatomic, copy) ZDBlock filterBlock;
@property (nonatomic, copy) ZDStringBlock urlBlock;

@end
