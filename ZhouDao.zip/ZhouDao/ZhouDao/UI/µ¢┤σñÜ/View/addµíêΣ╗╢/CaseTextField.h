//
//  CaseTextField.h
//  ZhouDao
//
//  Created by apple on 16/6/27.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CaseTextField : UITextField

@property (nonatomic, assign) NSInteger section;
@property (nonatomic, assign) NSInteger row;

@end
