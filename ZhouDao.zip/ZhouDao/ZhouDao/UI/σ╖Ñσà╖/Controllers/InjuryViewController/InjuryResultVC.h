//
//  InjuryResultVC.h
//  ZhouDao
//
//  Created by apple on 16/9/27.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface InjuryResultVC : BaseViewController


@property (nonatomic, strong) NSMutableDictionary *detailDictionary;

//city城市  level伤残等级   gongzi工资
@end
