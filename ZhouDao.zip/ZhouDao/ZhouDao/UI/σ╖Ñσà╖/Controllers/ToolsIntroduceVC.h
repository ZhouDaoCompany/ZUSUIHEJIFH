//
//  ToolsIntroduceVC.h
//  ZhouDao
//
//  Created by apple on 16/5/25.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ToolsIntroduceVC : BaseViewController


@property (nonatomic, copy) NSString *introContent;
@end
