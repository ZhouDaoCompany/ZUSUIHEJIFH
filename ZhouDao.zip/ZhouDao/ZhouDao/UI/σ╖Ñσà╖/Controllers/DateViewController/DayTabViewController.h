//
//  DayTabViewController.h
//  ZhouDao
//
//  Created by apple on 16/8/30.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol  DayTabViewControllerPro;

@interface DayTabViewController : UITableViewController


//@property (weak, nonatomic)   id<DayTabViewControllerPro>delegate;

@end
//@protocol  DayTabViewControllerPro <NSObject>
//
//- (void)DayTabViewControllerShareEvent;
//
//@end
