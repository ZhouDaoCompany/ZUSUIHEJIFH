//
//  BreachDetailCell.h
//  ZhouDao
//
//  Created by apple on 16/9/7.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BreachDetailCell : UITableViewCell

- (void)settUIWithArrays:(NSArray *)arrays;

@end
