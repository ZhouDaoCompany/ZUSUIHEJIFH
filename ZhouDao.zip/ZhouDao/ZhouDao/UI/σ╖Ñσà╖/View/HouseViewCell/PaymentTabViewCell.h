//
//  PaymentTabViewCell.h
//  ZhouDao
//
//  Created by apple on 16/9/13.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentTabViewCell : UITableViewCell


- (void)settingUIWithRow:(NSInteger)row withArrays:(NSArray *)arrays;
- (void)settingUIWithRow:(NSInteger)row withArrays1:(NSArray *)arrays1 withArrays2:(NSArray *)arrays2;

@end
