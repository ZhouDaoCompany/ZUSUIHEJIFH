//
//  ZDLTabBarControllerConfig.h
//  ZhouDao
//
//  Created by apple on 16/3/3.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CYLTabBarController.h"

@interface ZDLTabBarControllerConfig : NSObject

@property (nonatomic, readonly, strong) CYLTabBarController *tabBarController;

@end
