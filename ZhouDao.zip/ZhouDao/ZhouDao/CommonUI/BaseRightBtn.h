//
//  BaseRightBtn.h
//  ZhouDao
//
//  Created by apple on 16/7/29.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseRightBtn : UIButton

@end
