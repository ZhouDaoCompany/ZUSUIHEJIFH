//
//  APIKey.h
//  SearchV3Demo
//
//  Created by LES ES on 2014-09-15.
//  Copyright (c) 2014 LEAPP. All rights reserved.
//

#ifndef SearchV3Demo_APIKey_h
#define SearchV3Demo_APIKey_h

/* 使用高德SearchV3, 请首先注册APIKey, 注册APIKey请参考 http://api.amap.com
 */

const static NSString *APIKey = @"20ab3791f17fbdac8b769feb53d7fafc";

#endif
