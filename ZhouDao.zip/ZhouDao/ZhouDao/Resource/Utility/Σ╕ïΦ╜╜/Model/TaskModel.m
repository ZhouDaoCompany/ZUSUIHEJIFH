//
//  TaskModel.m
//  ZhouDao
//
//  Created by cqz on 16/3/25.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import "TaskModel.h"

@implementation TaskModel

+(instancetype)model
{
    return [[[self class]alloc] init];
}

@end
