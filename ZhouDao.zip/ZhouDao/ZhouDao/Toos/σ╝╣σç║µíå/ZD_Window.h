//
//  ZD_Window.h
//  ZhouDao
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 CQZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZD_Window : UIWindow

@property (nonatomic ,strong)UIView *zd_superView;

-(void)zd_Windowclose;

@end
