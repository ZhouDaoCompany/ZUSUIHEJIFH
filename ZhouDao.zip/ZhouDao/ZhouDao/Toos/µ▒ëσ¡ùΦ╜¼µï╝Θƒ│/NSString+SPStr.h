//
//  NSString+SPStr.h
//  searchTest
//
//  Created by 孙鹏 on 14-8-29.
//  Copyright (c) 2014年 ___sp___. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SPStr)
{
    
}

+ (NSString*)HanZiZhuanPinYin:(NSString*)HanZistr;

@end
